<html>
<body>
<center>

<?php
echo '<h3>You guessed above 100...that is not allowed!</h3>';
?>
<hr>
<b> Would you like to try again? </b>
<form>
<input type="button" onClick="parent.location='index.php'" value="Go Back!">
</form>

</center>
</body>
</html>
