<html>
<body onLoad="document.guessit.Num.focus()">
<center>
<br><br><hr><br>
<img src="img/AWS_Logo_Web_200px.png">
<br><hr>
<h3>Welcome to the Guessing Game!</h3>

<?php
$x = $_POST["x"];
$Num = $_POST["Num"];

//Starts our php document
if (!$x)
//if we have already defined x and started the game, this does not run

{
  Echo "Please Choose a Number 1-100 <p>";
  //gives the user instructions
  $x = rand (1,100) ;
  //creates x
}

else {
//this runs if the game is already in progress

//if the number is above 100, redirect to an error page
if ($Num > 100)
{header("Location: errorpage.php");
 exit();
}

if ($Num >$x)
{Echo "Your number, $Num, is too high. Please try again<p>";}
//if the number they guessed is bigger than x, it lets them know their guess was too high

elseif ($Num == $x)
{Echo "Congratulations you have won!<p><br>";
//if the number they guessed was correct it lets them know they won Echo "To play again, please Choose a Number 1-100 <p>";
Echo "To play again, just enter a new guess...<p>";
$x = rand (1,100) ;
//it then starts the game again by choosing a new value for $x that they can guess
}

else
{Echo "Your number, $Num, is too low. Please try again<p>";}
//if the answer is neither correct or to high, it tells them it is too low
}

?>

<form action="<?php echo $PHP_SELF; ?>" method="post" name="guessit">
<p>

Your Guess: <input name="Num" />

<input type = "submit" name = "Guess"/><p>

<input type = "hidden" name = "x" value=<?php echo $x ?>>

</form>
</body>
</html>

